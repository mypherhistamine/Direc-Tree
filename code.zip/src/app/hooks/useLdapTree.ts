import { useState, useEffect, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import { LdapNode } from "../models/LdapNode";
import { AttributeType } from "../models/AttributeTypeEnum";
import { findNodeRecursively } from "../utils";

/**
 * Custom hook that encapsulates all LDAP tree state and logic.
 * Keeps the component layer thin and focused on rendering.
 */
export function useLdapTree(treeData: LdapNode[]) {
	const [nodes, setNodes] = useState<LdapNode[]>([]);
	const [expandedNodes, setExpandedNodes] = useState<string[]>([]);
	const [selectedNode, setSelectedNode] = useState<LdapNode | null>(null);
	const [selectedAttributeContent, setSelectedAttributeContent] = useState<string | null>(null);
	const [selectedAttributeKey, setSelectedAttributeKey] = useState<string | null>(null);
	const [attributeType, setAttributeType] = useState<AttributeType>(AttributeType.String);
	const [isLoadingAttributes, setIsLoadingAttributes] = useState(false);

	// Sync nodes with incoming treeData prop
	useEffect(() => {
		setNodes(
			treeData.map((item, idx) => ({
				...item,
				id: item.dn,
				label: item.dn.split(",")[0],
				children: item.hasChildren
					? [
						{
							id: `placeholder-${idx}`,
							label: "Loading...",
							toggled: false,
							hasChildren: false,
							dn: "placeholder",
						},
					]
					: [],
			}))
		);
	}, [treeData]);

	const toggleNode = useCallback(
		async (nodeToToggle: LdapNode) => {
			const updateNode = async (node: LdapNode): Promise<LdapNode> => {
				if (node.dn === nodeToToggle.dn) {
					let childNodes: LdapNode[] = [];

					if (!node.toggled) {
						childNodes = await invoke<LdapNode[]>("fetch_ldap_tree", { baseDn: node.dn });
						childNodes = childNodes.map((child, idx) => ({
							...child,
							toggled: false,
							children: child.hasChildren
								? [
									{
										id: `placeholder-${child.dn}-${idx}`,
										label: "Loading...",
										toggled: false,
										hasChildren: false,
										dn: "placeholder",
									},
								]
								: [],
							id: child.dn,
							label: child.dn.split(",")[0],
						}));
					}

					return {
						...node,
						toggled: !node.toggled,
						children: node.toggled ? [] : childNodes,
					};
				}

				if (node.children && node.children.length > 0) {
					const updatedChildren = await Promise.all(node.children.map(updateNode));
					return { ...node, children: updatedChildren };
				}

				return node;
			};

			const updatedNodes = await Promise.all(nodes.map(updateNode));
			setNodes(updatedNodes);

			setExpandedNodes((prev) =>
				nodeToToggle.toggled
					? prev.filter((dn) => dn !== nodeToToggle.dn)
					: [...prev, nodeToToggle.dn]
			);
		},
		[nodes]
	);

	const fetchNodeAttributes = useCallback(async (node: LdapNode) => {
		setIsLoadingAttributes(true);
		try {
			const attributes = await invoke<Record<string, string>>("fetch_node_attributes", { baseDn: node.dn });
			setSelectedNode({ ...node, attributes });
		} finally {
			setIsLoadingAttributes(false);
		}
	}, []);

	const handleItemClick = useCallback(
		async (_event: React.MouseEvent, itemId: string) => {
			const ldapNode = findNodeRecursively(nodes, itemId);
			if (ldapNode) {
				await toggleNode(ldapNode);
				await fetchNodeAttributes(ldapNode);
			}
		},
		[nodes, toggleNode, fetchNodeAttributes]
	);

	const determineAndSetAttributeType = useCallback(async (value: string) => {
		try {
			const result: AttributeType = await invoke("determine_attribute_type", { value });
			setAttributeType(result);
		} catch {
			setAttributeType(AttributeType.String);
		}
	}, []);

	const handleAttributeClick = useCallback(
		async (key: string, value: string) => {
			setSelectedAttributeContent(value);
			setSelectedAttributeKey(key);
			await determineAndSetAttributeType(value);
		},
		[determineAndSetAttributeType]
	);

	const handleExportJson = useCallback(async () => {
		try {
			await invoke("get_parsed_json_tree");
		} catch (err) {
			console.error("Failed to export JSON:", err);
		}
	}, []);

	return {
		nodes,
		expandedNodes,
		selectedNode,
		selectedAttributeContent,
		selectedAttributeKey,
		attributeType,
		isLoadingAttributes,
		handleItemClick,
		handleAttributeClick,
		handleExportJson,
	};
}
