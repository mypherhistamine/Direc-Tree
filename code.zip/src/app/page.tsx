'use client'
import { invoke } from "@tauri-apps/api/core";
import { useEffect, useState } from "react";
import LdapTreeView from "./components/LdapTreeView";
import { LdapNode } from "./models/LdapNode";


export default function Home() {

	// const [_, setLdapEntries] = useState([]);
	const [ldapTree, setLdapTree] = useState<LdapNode[]>([]);



	const connectLdap = async () => {
		console.log("Connecting to the ldap connection")
		// await invoke<void>('connect_ldap');
		await invoke('connect_ldap');
		console.log("connected to the ldap connection")
	}



	// const getLdapObjects = async () => {
	// 	console.log("get_all_ldap_objects being called")
	// 	const entries = await invoke<[]>('get_all_ldap_objects')
	// 	setLdapEntries(entries);
	// }


	const fetchLdapTree = async () => {
		await connectLdap();
		console.log("fetching tree data");
		try {
			invoke<LdapNode[]>('fetch_ldap_tree', { baseDn: '' }).then((tree) => {
				console.log('Fetched LDAP Tree:', tree);
				setLdapTree(tree); // Set the tree data into state
			}) // Adjust type if needed

		} catch (error) {
			console.error('Error fetching LDAP tree:', error);
		}
	};

	// Call fetchLdapTree when component mounts
	useEffect(() => {
		fetchLdapTree();
	}, []);


	return (
		<main className="h-screen w-screen overflow-hidden bg-slate-900">
			<LdapTreeView treeData={ldapTree} />
		</main>
	);

}
