import React, { useState } from "react";
import { LdapNode } from "../models/LdapNode";
import { RichTreeView } from "@mui/x-tree-view";
import { CustomTreeItem } from "../utils";
import { Resizable } from "react-resizable";
import "react-resizable/css/styles.css";
import { useLdapTree } from "../hooks/useLdapTree";
import AttributePanel from "./AttributePanel";
import ContentPreview from "./ContentPreview";

interface LdapTreeViewProps {
	treeData: LdapNode[];
}

const LdapTreeView: React.FC<LdapTreeViewProps> = ({ treeData }) => {
	const [treeViewWidth, setTreeViewWidth] = useState(300);
	const [attrPanelWidth, setAttrPanelWidth] = useState(380);

	const {
		nodes,
		expandedNodes,
		selectedNode,
		selectedAttributeContent,
		selectedAttributeKey,
		attributeType,
		isLoadingAttributes,
		handleItemClick,
		handleAttributeClick,
		handleExportJson,
	} = useLdapTree(treeData);

	return (
		<div className="flex h-screen w-screen bg-slate-900 text-slate-100">

			{/* ─── Panel 1: LDAP Tree ─── */}
			<Resizable
				width={treeViewWidth}
				height={Infinity}
				minConstraints={[220, Infinity]}
				maxConstraints={[500, Infinity]}
				axis="x"
				onResize={(_e, { size }) => setTreeViewWidth(size.width)}
				resizeHandles={["e"]}
			>
				<aside
					style={{ width: `${treeViewWidth}px` }}
					className="h-full flex flex-col border-r border-slate-700/50 bg-slate-900"
				>
					{/* Panel Header */}
					<div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/60 flex items-center gap-2 flex-shrink-0">
						<svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
								d="M4 6h16M4 12h16M4 18h7" />
						</svg>
						<h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
							Directory Tree
						</h2>
					</div>

					{/* Tree Content */}
					<div className="flex-1 overflow-y-auto custom-scrollbar p-1">
						<RichTreeView
							slots={{ item: CustomTreeItem }}
							className="h-full text-slate-300"
							items={nodes}
							expandedItems={expandedNodes}
							onItemClick={(event, itemId) => handleItemClick(event, itemId)}
						/>
					</div>

					{/* Tree Footer / Actions */}
					<div className="px-3 py-2 border-t border-slate-700/50 bg-slate-800/40 flex-shrink-0">
						<button
							onClick={handleExportJson}
							className="w-full text-xs font-medium px-3 py-2 rounded-lg
								bg-blue-500/10 text-blue-400 border border-blue-500/20
								hover:bg-blue-500/20 hover:border-blue-500/40
								transition-all duration-200
								flex items-center justify-center gap-2"
						>
							<svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
								<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
									d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
							</svg>
							Export JSON
						</button>
					</div>
				</aside>
			</Resizable>

			{/* ─── Panel 2: Attributes ─── */}
			<Resizable
				width={attrPanelWidth}
				height={Infinity}
				minConstraints={[240, Infinity]}
				maxConstraints={[600, Infinity]}
				axis="x"
				onResize={(_e, { size }) => setAttrPanelWidth(size.width)}
				resizeHandles={["e"]}
			>
				<section
					style={{ width: `${attrPanelWidth}px` }}
					className="h-full flex flex-col border-r border-slate-700/50 bg-slate-900"
				>
					{/* Panel Header */}
					<div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/60 flex items-center gap-2 flex-shrink-0">
						<svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
								d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
						</svg>
						<h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
							Attributes
						</h2>
					</div>

					{/* Attribute Table */}
					<div className="flex-1 overflow-hidden">
						<AttributePanel
							selectedNode={selectedNode}
							selectedAttributeKey={selectedAttributeKey}
							isLoading={isLoadingAttributes}
							onAttributeClick={handleAttributeClick}
						/>
					</div>
				</section>
			</Resizable>

			{/* ─── Panel 3: Content Preview ─── */}
			<section className="flex-1 flex flex-col min-w-0 bg-slate-900/80">
				{/* Panel Header */}
				<div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/60 flex items-center gap-2 flex-shrink-0">
					<svg className="w-4 h-4 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
							d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
						<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
							d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
					</svg>
					<h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
						Content Preview
					</h2>
				</div>

				{/* Dynamic Content */}
				<div className="flex-1 overflow-hidden">
					<ContentPreview
						attributeType={attributeType}
						content={selectedAttributeContent}
						attributeKey={selectedAttributeKey}
					/>
				</div>
			</section>
		</div>
	);
};

export default LdapTreeView;
