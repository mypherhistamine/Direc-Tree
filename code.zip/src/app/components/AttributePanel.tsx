import React from "react";
import { LdapNode } from "../models/LdapNode";

interface AttributePanelProps {
	selectedNode: LdapNode | null;
	selectedAttributeKey: string | null;
	isLoading: boolean;
	onAttributeClick: (key: string, value: string) => void;
}

const AttributePanel: React.FC<AttributePanelProps> = ({
	selectedNode,
	selectedAttributeKey,
	isLoading,
	onAttributeClick,
}) => {
	if (isLoading) {
		return (
			<div className="flex items-center justify-center h-full text-slate-400">
				<div className="flex flex-col items-center gap-3">
					<div className="w-6 h-6 border-2 border-slate-500 border-t-blue-400 rounded-full animate-spin" />
					<span className="text-sm">Loading attributes...</span>
				</div>
			</div>
		);
	}

	if (!selectedNode) {
		return (
			<div className="flex items-center justify-center h-full text-slate-500">
				<div className="flex flex-col items-center gap-2 text-center px-6">
					<svg className="w-12 h-12 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
							d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
					</svg>
					<p className="text-sm font-medium">Select a node to view attributes</p>
					<p className="text-xs text-slate-600">Click on any item in the tree</p>
				</div>
			</div>
		);
	}

	const entries = selectedNode.attributes ? Object.entries(selectedNode.attributes) : [];

	return (
		<div className="flex flex-col h-full">
			{/* Header with DN */}
			<div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/50">
				<p className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-1">
					Distinguished Name
				</p>
				<p className="text-sm text-slate-200 font-mono break-all leading-relaxed">
					{selectedNode.dn}
				</p>
			</div>

			{/* Attributes Count */}
			<div className="px-4 py-2 border-b border-slate-700/50 flex items-center justify-between">
				<span className="text-xs text-slate-400">
					{entries.length} attribute{entries.length !== 1 ? "s" : ""}
				</span>
			</div>

			{/* Scrollable Table */}
			<div className="flex-1 overflow-y-auto custom-scrollbar">
				<table className="w-full text-sm">
					<thead className="sticky top-0 z-10">
						<tr className="bg-slate-800">
							<th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700/50 w-[40%]">
								Attribute
							</th>
							<th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700/50">
								Value
							</th>
						</tr>
					</thead>
					<tbody>
						{entries.map(([key, value], index) => {
							const isSelected = key === selectedAttributeKey;
							return (
								<tr
									key={key}
									onClick={() => onAttributeClick(key, value)}
									className={`
										cursor-pointer transition-colors duration-150
										${isSelected
											? "bg-blue-500/15 border-l-2 border-l-blue-400"
											: index % 2 === 0
												? "bg-transparent border-l-2 border-l-transparent"
												: "bg-slate-800/30 border-l-2 border-l-transparent"
										}
										hover:bg-slate-700/50
									`}
								>
									<td className="px-4 py-2 font-medium text-slate-300 whitespace-nowrap">
										<span className="flex items-center gap-1.5">
											<span className="w-1.5 h-1.5 rounded-full bg-blue-400/60 flex-shrink-0" />
											{key}
										</span>
									</td>
									<td
										className="px-4 py-2 text-slate-400 truncate max-w-[300px] font-mono text-xs"
										title={value}
									>
										{value}
									</td>
								</tr>
							);
						})}
					</tbody>
				</table>
			</div>
		</div>
	);
};

export default AttributePanel;
