import React, { useCallback } from "react";
import { AttributeType } from "../models/AttributeTypeEnum";
import XmlContentViewer from "./XmlContentViewer";
import Base64ImageDisplay from "./Base64ImageDisplay";
import JsonView from "@uiw/react-json-view";
import { darkTheme } from "@uiw/react-json-view/dark";

interface ContentPreviewProps {
	attributeType: AttributeType;
	content: string | null;
	attributeKey: string | null;
}

/** Returns MIME type and file extension for the current attribute type */
function getDownloadMeta(type: AttributeType): { mime: string; ext: string } {
	switch (type) {
		case AttributeType.Xml:
			return { mime: "application/xml", ext: "xml" };
		case AttributeType.Json:
			return { mime: "application/json", ext: "json" };
		case AttributeType.Base64:
			return { mime: "image/png", ext: "png" };
		case AttributeType.String:
		default:
			return { mime: "text/plain", ext: "txt" };
	}
}

const ContentPreview: React.FC<ContentPreviewProps> = ({
	attributeType,
	content,
	attributeKey,
}) => {
	const handleDownload = useCallback(() => {
		if (!content) return;

		const { mime, ext } = getDownloadMeta(attributeType);
		const fileName = `${(attributeKey ?? "content").replace(/[^a-zA-Z0-9_-]/g, "_")}.${ext}`;

		let blob: Blob;
		if (attributeType === AttributeType.Base64) {
			// Decode base64 to binary for image download
			try {
				const byteChars = atob(content);
				const byteArray = new Uint8Array(byteChars.length);
				for (let i = 0; i < byteChars.length; i++) {
					byteArray[i] = byteChars.charCodeAt(i);
				}
				blob = new Blob([byteArray], { type: mime });
			} catch {
				blob = new Blob([content], { type: "text/plain" });
			}
		} else if (attributeType === AttributeType.Json) {
			// Pretty-print JSON
			try {
				const pretty = JSON.stringify(JSON.parse(content), null, 2);
				blob = new Blob([pretty], { type: mime });
			} catch {
				blob = new Blob([content], { type: mime });
			}
		} else {
			blob = new Blob([content], { type: mime });
		}

		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = fileName;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
	}, [content, attributeType, attributeKey]);

	if (!content) {
		return (
			<div className="flex items-center justify-center h-full text-slate-500">
				<div className="flex flex-col items-center gap-2 text-center px-6">
					<svg className="w-12 h-12 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
						<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
							d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
					</svg>
					<p className="text-sm font-medium">No content selected</p>
					<p className="text-xs text-slate-600">Click an attribute to preview its value</p>
				</div>
			</div>
		);
	}

	const renderTypeBadge = () => {
		const badges: Record<AttributeType, { label: string; color: string }> = {
			[AttributeType.Xml]: { label: "XML", color: "bg-pink-500/20 text-pink-300 border-pink-500/30" },
			[AttributeType.Json]: { label: "JSON", color: "bg-amber-500/20 text-amber-300 border-amber-500/30" },
			[AttributeType.Base64]: { label: "BASE64", color: "bg-purple-500/20 text-purple-300 border-purple-500/30" },
			[AttributeType.String]: { label: "STRING", color: "bg-slate-500/20 text-slate-300 border-slate-500/30" },
		};
		const badge = badges[attributeType];
		return (
			<span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${badge.color}`}>
				{badge.label}
			</span>
		);
	};

	const renderContent = () => {
		switch (attributeType) {
			case AttributeType.Xml:
				return <XmlContentViewer xml={content} />;

			case AttributeType.Json:
				try {
					return (
						<div className="p-4 overflow-auto custom-scrollbar h-full">
							<JsonView
								value={JSON.parse(content)}
								displayDataTypes={false}
								style={{
									...darkTheme,
									backgroundColor: "transparent",
								}}
							/>
						</div>
					);
				} catch {
					return <PlainTextView content={content} />;
				}

			case AttributeType.Base64:
				return (
					<div className="flex items-center justify-center h-full p-4">
						<Base64ImageDisplay base64String={content} />
					</div>
				);

			case AttributeType.String:
			default:
				return <PlainTextView content={content} />;
		}
	};

	return (
		<div className="flex flex-col h-full">
			{/* Preview Header */}
			<div className="px-4 py-3 border-b border-slate-700/50 bg-slate-800/50 flex items-center justify-between gap-3">
				<div className="min-w-0 flex-1">
					<p className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-0.5">
						Preview
					</p>
					{attributeKey && (
						<p className="text-sm text-slate-200 font-mono truncate" title={attributeKey}>
							{attributeKey}
						</p>
					)}
				</div>
				<div className="flex items-center gap-2">
					{renderTypeBadge()}
					<button
						onClick={handleDownload}
						title="Download content"
						className="p-1.5 rounded-lg text-slate-400
							bg-slate-700/40 border border-slate-600/30
							hover:bg-slate-600/50 hover:text-slate-200 hover:border-slate-500/50
							transition-all duration-150"
					>
						<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
							<path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
								d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
						</svg>
					</button>
				</div>
			</div>

			{/* Content Area */}
			<div className="flex-1 overflow-hidden">
				{renderContent()}
			</div>
		</div>
	);
};

/** Simple text display for string-type attributes */
const PlainTextView: React.FC<{ content: string }> = ({ content }) => (
	<div className="p-4 h-full overflow-auto custom-scrollbar">
		<pre className="text-sm text-slate-300 font-mono whitespace-pre-wrap break-all leading-relaxed">
			{content}
		</pre>
	</div>
);

export default ContentPreview;
