import * as React from 'react';
import clsx from 'clsx';
import { styled, alpha } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import Typography from '@mui/material/Typography';
import { treeItemClasses, TreeItemProps } from '@mui/x-tree-view/TreeItem';
import { useTreeItem2, UseTreeItem2Parameters } from '@mui/x-tree-view/useTreeItem2';
import {
	TreeItem2Checkbox,
	TreeItem2Content,
	TreeItem2IconContainer,
	TreeItem2Label,
	TreeItem2Root,
} from '@mui/x-tree-view/TreeItem2';
import { TreeItem2Icon } from '@mui/x-tree-view/TreeItem2Icon';
import { TreeItem2Provider } from '@mui/x-tree-view/TreeItem2Provider';
import { TreeItem2DragAndDropOverlay } from '@mui/x-tree-view/TreeItem2DragAndDropOverlay';
import { TreeViewBaseItem } from '@mui/x-tree-view/models';
import { TransitionProps } from '@mui/material/transitions';
// import { animated, useSpring } from 'react-spring';
import { RichTreeView } from '@mui/x-tree-view';
import ArticleIcon from '@mui/icons-material/Article';
import DeleteIcon from '@mui/icons-material/Delete';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import FolderRounded from '@mui/icons-material/FolderRounded';
import ImageIcon from '@mui/icons-material/Image';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import VideoCameraBackIcon from '@mui/icons-material/VideoCameraBack';
import { motion } from 'framer-motion';
import { JSXElementConstructor } from 'react';
// import { animated, useSpring } from '@react-spring/web';

type FileType = 'image' | 'pdf' | 'doc' | 'video' | 'folder' | 'pinned' | 'trash';

type ExtendedTreeItemProps = {
	fileType?: FileType;
	id: string;
	label: string;
};

function DotIcon() {
	return (
		<Box
			sx={{
				width: 6,
				height: 6,
				borderRadius: '70%',
				bgcolor: 'warning.main',
				display: 'inline-block',
				verticalAlign: 'middle',
				zIndex: 1,
				mx: 1,
			}}
		/>
	);
}

const StyledTreeItemRoot = styled(TreeItem2Root)(({ theme }) => ({
	color: theme.palette.grey[400],
	position: 'relative',
	[`& .${treeItemClasses.groupTransition}`]: {
		marginLeft: theme.spacing(3.5),
	},
	...theme.applyStyles('light', {
		color: theme.palette.grey[800],
	}),
})) as unknown as typeof TreeItem2Root;

const CustomTreeItemContent = styled(TreeItem2Content)(({ theme }) => ({
	flexDirection: 'row-reverse',
	borderRadius: theme.spacing(0.7),
	marginBottom: theme.spacing(0.5),
	marginTop: theme.spacing(0.5),
	padding: theme.spacing(0.5),
	paddingLeft: theme.spacing(2), // Add custom left padding for indentation
	paddingRight: theme.spacing(1),
	fontWeight: 500,
	[`&.Mui-expanded `]: {
		'&:not(.Mui-focused, .Mui-selected, .Mui-selected.Mui-focused) .labelIcon': {
			color: theme.palette.primary.dark,
			...theme.applyStyles('light', {
				color: theme.palette.primary.main,
			}),
		},
		'&::before': {
			content: '""',
			display: 'block',
			position: 'absolute',
			left: '16px',
			top: '44px',
			height: 'calc(100% - 48px)',
			width: '1.5px',
			backgroundColor: theme.palette.grey[700],
			...theme.applyStyles('light', {
				backgroundColor: theme.palette.grey[300],
			}),
		},
	},
	'&:hover': {
		backgroundColor: alpha(theme.palette.primary.main, 0.1),
		color: 'white',
		...theme.applyStyles('light', {
			color: theme.palette.primary.main,
		}),
	},
	[`&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused`]: {
		backgroundColor: theme.palette.primary.dark,
		color: theme.palette.primary.contrastText,
		...theme.applyStyles('light', {
			backgroundColor: theme.palette.primary.main,
		}),
	},
}));

function TransitionComponent(props: TransitionProps) {
	return (
		<motion.div
			initial={{ opacity: 0, y: 20 }}
			animate={{ opacity: props.in ? 1 : 0, y: props.in ? 0 : 20 }}
			transition={{ duration: 0.3 }}
		>
			<Collapse in={props.in} {...props} />
		</motion.div>
	);
}

const StyledTreeItemLabelText = styled(Typography)({
	color: 'inherit',
	fontFamily: 'General Sans',
	fontWeight: 500,
}) as unknown as typeof Typography;

interface CustomLabelProps {
	children: React.ReactNode;
	icon?: React.ElementType;
	expandable?: boolean;
}

function CustomLabel({
	icon: Icon,
	expandable,
	children,
	...other
}: CustomLabelProps) {
	return (
		<TreeItem2Label
			{...other}
			sx={{
				display: 'flex',
				alignItems: 'center',
			}}
		>
			{Icon && (
				<Box
					component={Icon}
					className="labelIcon"
					color="inherit"
					sx={{ mr: 1, fontSize: '1.2rem' }}
				/>
			)}

			<StyledTreeItemLabelText variant="body2">{children}</StyledTreeItemLabelText>
			{expandable && <DotIcon />}
		</TreeItem2Label>
	);
}

const isExpandable = (reactChildren: React.ReactNode) => {
	if (Array.isArray(reactChildren)) {
		return reactChildren.length > 0 && reactChildren.some(isExpandable);
	}
	return Boolean(reactChildren);
};

const getIconFromFileType = (fileType: FileType) => {
	switch (fileType) {
		case 'image':
			return ImageIcon;
		case 'pdf':
			return PictureAsPdfIcon;
		case 'doc':
			return ArticleIcon;
		case 'video':
			return VideoCameraBackIcon;
		case 'folder':
			return FolderRounded;
		case 'pinned':
			return FolderOpenIcon;
		case 'trash':
			return DeleteIcon;
		default:
			return ArticleIcon;
	}
};

interface CustomTreeItemProps {
	id: string;  // Make sure id is required here
	label: string;
	fileType?: FileType;
	children?: React.ReactNode;
	itemId: string;
	disabled: boolean;
	// other props...
}

export const CustomTreeItem = React.forwardRef(function CustomTreeItem(
	props: CustomTreeItemProps,
	ref: React.Ref<HTMLLIElement>,
) {
	const { id, itemId, label, disabled, children, ...other } = props;

	const {
		getRootProps,
		getContentProps,
		getIconContainerProps,
		getCheckboxProps,
		getLabelProps,
		getGroupTransitionProps,
		getDragAndDropOverlayProps,
		status,
		publicAPI,
	} = useTreeItem2({ id, itemId, children, label, disabled, rootRef: ref });

	const item = publicAPI.getItem(itemId);
	const expandable = isExpandable(children);
	let icon;
	if (expandable) {
		icon = FolderRounded;
	} else if (item.fileType) {
		icon = getIconFromFileType(item.fileType);
	}

	return (
		<TreeItem2Provider itemId={itemId}>
			<StyledTreeItemRoot {...getRootProps(other)}>
				<CustomTreeItemContent
					{...getContentProps({
						className: clsx('content', {
							'Mui-expanded': status.expanded,
							'Mui-selected': status.selected,
							'Mui-focused': status.focused,
							'Mui-disabled': status.disabled,
						}),
					})}
				>
					<TreeItem2IconContainer {...getIconContainerProps()}>
						<TreeItem2Icon status={status} />
					</TreeItem2IconContainer>
					<TreeItem2Checkbox {...getCheckboxProps()} />
					<CustomLabel
						{...getLabelProps({ icon, expandable: expandable && status.expanded })}
					/>
					<TreeItem2DragAndDropOverlay {...getDragAndDropOverlayProps()} />
				</CustomTreeItemContent>
				{children && <TransitionComponent {...getGroupTransitionProps()} />}
			</StyledTreeItemRoot>
		</TreeItem2Provider>
	);
});

export default function FileExplorer({ items }: { items: TreeViewBaseItem<ExtendedTreeItemProps>[] }) {
	return (
		<RichTreeView
			items={items}
			defaultExpandedItems={['1', '1.1']}
			defaultSelectedItems="1.1"
			sx={{ height: 'fit-content', flexGrow: 1, maxWidth: 400, overflowY: 'auto' }}
			slots={{ item: CustomTreeItem as unknown as JSXElementConstructor<TreeItemProps> }}
		/>
	);
}
