mod commands;
mod constants;
mod ldap_conn;
mod models;
mod state_management;
use std::sync::{Arc, Mutex};
use tauri_plugin_clipboard_manager::init as clipboard_init;

use state_management::app_state::AppState;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let app_state = Arc::new(Mutex::new(AppState::default()));
    tauri::Builder::default()
        .plugin(clipboard_init())
        .setup(|app| {
            if cfg!(debug_assertions) {
                app.handle().plugin(
                    tauri_plugin_log::Builder::default()
                        .level(log::LevelFilter::Info)
                        .build(),
                )?;
            }
            Ok(())
        })
        .manage(app_state) // Ensure AppState is registered here
        .invoke_handler(tauri::generate_handler![
            commands::connect_ldap::connect_ldap,
            commands::get_all_ldap_objects::get_all_ldap_objects,
            commands::fetch_ldap_tree::fetch_ldap_tree,
            commands::fetch_ldap_tree::get_parsed_json_tree,
            commands::fetch_ldap_entry_attrs::fetch_node_attributes,
            commands::fetch_ldap_entry_attrs::determine_attribute_type
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
